//
//  Url.h
//  IBank
//
//  Created by 王    帅 on 12/3/19.
//  Copyright © 2019年 Alibaba. All rights reserved.
//  接口地址

#ifndef Url_h
#define Url_h

//登录
#define LOGINFLAGCHK @"com.pactera.madp.msz.db.user.loginFlagChk"//登录标识检查
#define SETGESTUREPWD @"com.pactera.madp.msz.db.user.gesturePwdOpenInput"//设置指纹
#define LOGIN @"com.pactera.madp.msz.db.user.login"//登录



#endif /* Url_h */
